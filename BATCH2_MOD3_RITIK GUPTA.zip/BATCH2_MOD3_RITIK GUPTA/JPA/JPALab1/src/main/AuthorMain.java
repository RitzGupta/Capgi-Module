package main;

import java.util.List;
import java.util.Scanner;

import bean.Author;
import dao.AuthorDao;

public class AuthorMain {
	public static void main(String args[]) {
		System.out.println("Welcome to crud Operations");
		AuthorDao ad = new AuthorDao();
		Author author1 = new Author();
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("1. Create new Author\n" + "2. Get Author by Author Id\n"
					+ "3. Delete Authir by Id\n" + "4. Update Author Details\n" +"5. Exit");
			int n = sc.nextInt();
			switch (n) {
			case 1: {
				System.out.println("Enter Author Details");
				System.out.println("Author First Name");
				String firstName = sc.next();
				author1.setFirstName(firstName);
				System.out.println("Author Middle Name");
				String middleName = sc.next();
				author1.setMiddleName(middleName);
				System.out.println("Author Last Name");
				String lastName = sc.next();
				author1.setLastName(lastName);
				System.out.println("Author PhoneNo.");
				String phoneNo = sc.next();
				author1.setPhoneNo(phoneNo);
				String result = ad.createAuthor(author1);
				System.out.println(result);
				break;
			}
			case 2: {
				System.out.println("Get Author by Author Id");
				System.out.println("Enter Author Id");
				int aId = sc.nextInt();
				Author a1 = ad.findAuthorById(aId);
				System.out.println(a1);
				break;
			}
			case 3: {
				System.out.println("Delete Author");
				System.out.println("Enter the Author Id");
				String deletedAuthor = ad.deleteAuthor(sc.nextInt());
				System.out.println(deletedAuthor);
				break;
			}
			case 4: {
				System.out.println("Update Author Name");
				System.out.println("Enter StudentId");
				System.out.println("Author ID");
				int id = sc.nextInt();
				System.out.println("Author First Name");
				String firstName = sc.next();
				System.out.println("Author Middle Name");
				String middleName = sc.next();
				System.out.println("Author Last Name");
				String lastName = sc.next();
				System.out.println("Author PhoneNo.");
				String phoneNo = sc.next();
				String update = ad.updateNameAuthor(id, firstName, middleName, lastName, phoneNo);
				System.out.println(update);
				break;
			}
			case 5: {
				System.exit(0);
			}

			}

		}


	}

}
