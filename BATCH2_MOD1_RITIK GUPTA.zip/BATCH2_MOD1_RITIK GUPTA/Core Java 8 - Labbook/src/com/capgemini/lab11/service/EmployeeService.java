package com.capgemini.lab11.service;

import java.util.Set;

import com.capgemini.lab11.bean.Employee;

public interface EmployeeService {
	
	void addEmployee(Employee e);
	Set<Employee> AllEmployee();
	String scheme(float salary,String designation);
	

}
