package com.capgemini.lab5.exercise6;

import java.util.Scanner;

class MyException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public MyException(String msg) {
		super(msg) ;
	}
}
public class ValidateSalary{

	public static void main(String[] args) {
			try {
				Scanner sc=new Scanner(System.in);
				int salary=sc.nextInt();
				sc.close();
				if(salary<3000)
					throw new MyException("Salary is less than 3000!!!!");
				else	
					System.out.println("Valid salary");
			}
			catch(MyException e)
			{
				System.out.println(e.getMessage());
			}
			
		}

	}
	
