package com.capgemini.lab5.exercise3;

import java.util.Scanner;

public class PrimeNumberMain {
	public static void main(String[] args)  
	{
		Scanner sc=new Scanner(System.in);
	    int n = sc.nextInt(); 
	    PrimeNumber.printPrime(n); 
	    sc.close();
	} 
	} 

