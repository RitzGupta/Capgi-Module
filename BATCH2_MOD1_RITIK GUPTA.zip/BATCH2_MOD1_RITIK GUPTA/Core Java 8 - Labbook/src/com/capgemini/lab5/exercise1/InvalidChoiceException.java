package com.capgemini.lab5.exercise1;

public class InvalidChoiceException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public InvalidChoiceException(String msg) {
		super(msg) ;
	}
}
