package com.capgemini.lab5.exercise5;

import java.util.Scanner;

class myException extends Exception {

	private static final long serialVersionUID = 1L;

	myException(String s) {
		super(s);
	}
}

public class ValidateAge {

	public static void main(String[] args) {
		try {
			Scanner sc = new Scanner(System.in);
			int age = sc.nextInt();
			sc.close();
			if (age < 15) {
				throw new myException("Age is less than 15!! Not valid");
			} else {
				System.out.println("Age is valid");
			}
		} catch (myException e) {
			System.out.println(e.getMessage());
		}
	}

}
