package com.capgemini.lab6.exercise1;

public class SumOfIntegerMain {

	public static void main(String[] args) {
			
			SumOfInteger obj=new SumOfInteger();
			System.out.println(obj.sumofToken());
		}

	}

