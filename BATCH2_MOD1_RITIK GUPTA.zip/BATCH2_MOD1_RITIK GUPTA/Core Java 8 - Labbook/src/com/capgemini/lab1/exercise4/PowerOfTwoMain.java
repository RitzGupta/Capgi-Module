package com.capgemini.lab1.exercise4;

public class PowerOfTwoMain {

	public static void main(String[] args) {
		PowerOfTwo obj=new PowerOfTwo();
		System.out.println(obj.check());

	}

}
