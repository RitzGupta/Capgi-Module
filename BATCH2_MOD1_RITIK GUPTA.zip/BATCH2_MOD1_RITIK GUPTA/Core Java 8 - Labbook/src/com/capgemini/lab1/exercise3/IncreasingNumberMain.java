package com.capgemini.lab1.exercise3;

public class IncreasingNumberMain {

	public static void main(String[] args) {
		IncreasingNumber obj=new IncreasingNumber();
		System.out.println(obj.checknumber());

	}

}
