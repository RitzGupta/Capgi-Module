package com.capgemini.lab1.exercise1;

public class CalculateSumMain {

	public static void main(String[] args) {
		CalculateSum obj=new CalculateSum();
		System.out.println("SUM="+obj.sumfunc());

	}

}
