package com.capgemini.lab1.exercise2;

public class DifferenceSumMain {

	public static void main(String[] args) {
		DifferenceSum obj=new DifferenceSum();
		System.out.println(obj.CalculateDiff());

	}

}
