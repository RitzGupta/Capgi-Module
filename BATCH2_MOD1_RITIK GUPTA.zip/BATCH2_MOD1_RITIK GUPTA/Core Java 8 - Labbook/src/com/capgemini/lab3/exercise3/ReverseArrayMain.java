package com.capgemini.lab3.exercise3;

public class ReverseArrayMain {
	public static void main(String[] args) {
		ReverseArray obj=new ReverseArray();
		obj.getData();
		obj.displayData();
		obj.reverseSort();

	}

}
