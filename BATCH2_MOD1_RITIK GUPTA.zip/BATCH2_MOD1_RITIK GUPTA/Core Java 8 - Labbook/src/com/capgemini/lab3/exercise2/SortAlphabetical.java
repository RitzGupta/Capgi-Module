package com.capgemini.lab3.exercise2;

public class SortAlphabetical {

}
