package com.capgemini.lab3.exercise4;

import java.util.Scanner;

public class MainClass {
	public static void main(String[] args) 
	{ 
		Scanner sc = new Scanner(System.in); 
		String str = sc.nextLine(); 
		NoOfOccurenceOfCharacters.getOccuringChar(str);
		sc.close();
	} 
}
