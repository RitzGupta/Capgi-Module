package com.capgemini.lab3.exercise1;


public class SecondSmallestMain {

	public static void main(String[] args) {
		SecondSmallest obj=new SecondSmallest();
		obj.getValues();
		System.out.println(obj.findSmallest());


	}

}
