package com.capgemini.lab10;

interface Demo {
	Exercise4 Method1(int sample1, String sample2);
}

public class Exercise4 {
	private int sample1;
	private String sample2;

	public Exercise4(int sample1, String sample2) {
		this.sample1 = sample1;
		this.sample2 = sample2;
		System.out.println(sample1 + sample2);
	}

	public int getSample1() {
		return sample1;
	}

	public void setSample1(int sample1) {
		this.sample1 = sample1;
	}

	public String getSample2() {
		return sample2;
	}

	public void setSample2(String sample2) {
		this.sample2 = sample2;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Demo result = Exercise4::new;
		result.Method1(1, "Capgemini");
	}

}
