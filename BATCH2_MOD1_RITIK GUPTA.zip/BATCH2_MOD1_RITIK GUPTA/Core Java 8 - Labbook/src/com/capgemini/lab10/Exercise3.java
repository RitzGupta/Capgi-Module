package com.capgemini.lab10;

interface Validation{
	public boolean validate(String userName, String password) ;
}

public class Exercise3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String userName="Hello", password="password" ;
		Validation v = (uName, pass) -> uName.equals(userName)?pass.equals(password)?true:false :false ;
		System.out.println(v.validate(userName, password));

	}

}
