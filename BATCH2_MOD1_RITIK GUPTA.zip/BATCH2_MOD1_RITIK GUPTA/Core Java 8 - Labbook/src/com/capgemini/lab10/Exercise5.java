package com.capgemini.lab10;

interface Demo5{
	int Calculate(int number) ;
}

public class Exercise5 {
	
	public int Fact(int number) {
		int result = number ;
		while(number>0) {
			result *= number-1 ;
			number-- ;
		}
		return result ;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Exercise5 obj = new Exercise5() ;
		Demo5 ref = obj::Fact ;
		System.out.println(ref.Calculate(4)) ;
	}

}
