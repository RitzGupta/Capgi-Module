package com.capgemini.lab10;


interface Power{
	public int powerNumber(int x, int y) ;
}


public class Demo1{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Power p1 = (x,y) -> (int)Math.pow(x, y) ;
		System.out.println(p1.powerNumber(2, 4));
	}
}