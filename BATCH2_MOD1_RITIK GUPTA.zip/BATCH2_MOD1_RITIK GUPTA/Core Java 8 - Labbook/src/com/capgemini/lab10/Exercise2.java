package com.capgemini.lab10;


interface Space{
	public String space(String str) ;
}

public class Exercise2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String sample = "hey how are you" ;
		Space s = (str) -> str.replaceAll("", " ").trim() ;
		System.out.println(s.space(sample));
		
	}

}
