package com.capgemini.lab8;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


public class Thread1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ScheduledExecutorService service = Executors.newScheduledThreadPool(10);

		service.scheduleAtFixedRate(new Task(), 0, 1, TimeUnit.SECONDS);

		//service.scheduleWithFixedDelay(new Task(), 10, 10, TimeUnit.SECONDS);

	}

}

class Task implements Runnable {
	
	@Override
	public void run() {
		System.out.println("Thread working " + Thread.currentThread().getName());
	}
}