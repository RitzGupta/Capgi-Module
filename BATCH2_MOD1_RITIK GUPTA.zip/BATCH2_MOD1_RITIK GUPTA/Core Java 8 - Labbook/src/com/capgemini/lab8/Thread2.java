package com.capgemini.lab8;

import java.util.*;

public class Thread2 implements Runnable {

	@Override
	public void run() {
		while (true) {
			System.out.println("System at : " + new Date());
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		Thread2 t2 = new Thread2();
		t2.run();
	}
}
