package com.capgemini.lab4.exercise1 ;

public class SumOfCubeMain {

	public static void main(String[] args) {
		SumOfCubes obj=new SumOfCubes();
		System.out.println(obj.sumFunction(obj.num));
	}

}
